package classes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class TestSuite {
	public int TestSuiteID;
	public String TestSuiteName;
	
	
	
	public TestSuite(int testSuiteID, String testSuiteName) {
		this.TestSuiteID = testSuiteID;
		this.TestSuiteName = testSuiteName;
	}
	
	public TestSuite(){
		this.TestSuiteID = 0;
		this.TestSuiteName = "";
	}


public void addTestSuite(TestSuite testSuite, List<Integer> scriptIDs){
		
		int suiteID;
		
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch (InstantiationException e) {
			System.out.println("InstantiationException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		} catch (IllegalAccessException e) {
			System.out.println("IllegalAccessException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		
		Connection conn = null;

		try {
			conn = DriverManager.getConnection(DatabaseInfo.url, DatabaseInfo.username, DatabaseInfo.password);
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		String query = "INSERT INTO TestSuites (TestSuiteName) VALUES ('" +testSuite.TestSuiteName + "');";
		

		try {
			Statement stmt = conn.createStatement();
			suiteID = stmt.executeUpdate(query, Statement.RETURN_GENERATED_KEYS);
		} catch (SQLException e) {
			System.out.println("FirstSQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		
		query = "INSERT INTO TestGrouping (ScriptID, TestSuiteID) VALUES (?, ?);";
		PreparedStatement ps = null;
		
		for(Integer i : scriptIDs){
			ps = null;
			try {
				ps = conn.prepareStatement(query);
				ps.setInt(1, i);
				ps.setInt(2, suiteID);
				ps.executeUpdate();
			} catch (SQLException e) {
				System.out.println("SecondSQLException: ");
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}
		
		try {
			if(ps != null && !ps.isClosed())
				ps.close();
			if(conn != null && !conn.isClosed())
				conn.close();
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		return;	
	}

	public ArrayList<TestSuite> getTestSuites(){
		
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch (InstantiationException e) {
			System.out.println("InstantiationException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		} catch (IllegalAccessException e) {
			System.out.println("IllegalAccessException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		
		Connection conn = null;

		try {
			conn = DriverManager.getConnection(DatabaseInfo.url, DatabaseInfo.username, DatabaseInfo.password);
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		String query = "SELECT * FROM TestSuites";
		ArrayList<TestSuite> testSuites = new ArrayList<TestSuite>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();
			while(rs.next()) {
				String testSuiteId = rs.getString("TestSuiteID");
				String testSuiteName = rs.getString("TestSuiteName");
				testSuites.add(new TestSuite(Integer.parseInt(testSuiteId), testSuiteName));
			}
			rs.close();
		}catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}try {
			if(rs != null && !rs.isClosed())
				rs.close();
			if(ps != null && !ps.isClosed())
				ps.close();
			if(conn != null && !conn.isClosed())
				conn.close();
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		return testSuites;	
	}
}
