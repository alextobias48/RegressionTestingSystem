package classes;

import java.util.ArrayList;
import java.util.List;

import classes.TestSuite;

import javax.servlet.http.*;

public class TestSuiteServlet extends HttpServlet{
	private static final long serialVersionUID = 1L; 

	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		
		String testSuiteName  = request.getParameter("suiteName");
		String selectedScripts = request.getParameter("hidSelectedScripts");
		
		if(selectedScripts.length() > 0){
			String scripts[] = selectedScripts.split(","); 
			List<Integer> scriptIDs = new ArrayList<Integer>();
		
			for(String s : scripts){
				scriptIDs.add(Integer.parseInt(s));
			}
			
			TestSuite testSuite = new TestSuite(0, testSuiteName);
			testSuite.addTestSuite(testSuite, scriptIDs);	
		}
				
		try {
			response.sendRedirect("ScriptUpload.jsp");
		} catch (Exception e) {
			
		}

	}
}