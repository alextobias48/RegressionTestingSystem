package classes;

public class DatabaseInfo {
	public static final String url = "jdbc:mysql://cse.unl.edu/atobia";
	public static final String username = "atobia";
	public static final String password = "Gonzagazags44";
}
