package classes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class SuiteResult {
	public int suiteResultID;
	public int testSuiteID;
	public String suiteRunTime;
	public String tabStyle;
	
	
	public SuiteResult(int suiteResultID, int testSuiteID, String suiteRunTime, String style) {
		this.suiteResultID = suiteResultID;
		this.testSuiteID = testSuiteID;
		this.suiteRunTime = suiteRunTime;
		this.tabStyle = style;
	}
	
	public SuiteResult() {
		this.suiteResultID = 0;
		this.testSuiteID = 0;
		this.suiteRunTime = "";
	}
	
public String getSuiteName(){

	try {
		Class.forName("com.mysql.jdbc.Driver").newInstance();
	} catch (InstantiationException e) {
		System.out.println("InstantiationException: ");
		e.printStackTrace();
		throw new RuntimeException(e);
	} catch (IllegalAccessException e) {
		System.out.println("IllegalAccessException: ");
		e.printStackTrace();
		throw new RuntimeException(e);
	} catch (ClassNotFoundException e) {
		System.out.println("ClassNotFoundException: ");
		e.printStackTrace();
		throw new RuntimeException(e);
	}
	
	Connection conn = null;

	try {
		conn = DriverManager.getConnection(DatabaseInfo.url, DatabaseInfo.username, DatabaseInfo.password);
	} catch (SQLException e) {
		System.out.println("SQLException: ");
		e.printStackTrace();
		throw new RuntimeException(e);
	}
	String query = "SELECT * FROM TestSuites t WHERE t.TestSuiteID = " + this.testSuiteID + ";";
	String suiteName = "";
	PreparedStatement ps = null;
	ResultSet rs = null;
	
	try {
		ps = conn.prepareStatement(query);
		rs = ps.executeQuery();
		if(rs.next()) {
			suiteName = rs.getString("TestSuiteName");
		}
		rs.close();
	}catch (SQLException e) {
		System.out.println("SQLException: ");
		e.printStackTrace();
		throw new RuntimeException(e);
	}try {
		if(rs != null && !rs.isClosed())
			rs.close();
		if(ps != null && !ps.isClosed())
			ps.close();
		if(conn != null && !conn.isClosed())
			conn.close();
	} catch (SQLException e) {
		System.out.println("SQLException: ");
		e.printStackTrace();
		throw new RuntimeException(e);
	}
	
	return suiteName;
}
	
public ArrayList<SuiteResult> getSuiteResults(){
		
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch (InstantiationException e) {
			System.out.println("InstantiationException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		} catch (IllegalAccessException e) {
			System.out.println("IllegalAccessException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		
		Connection conn = null;

		try {
			conn = DriverManager.getConnection(DatabaseInfo.url, DatabaseInfo.username, DatabaseInfo.password);
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		String query = "SELECT * FROM SuiteResults;";
		ArrayList<SuiteResult> suiteResult = new ArrayList<SuiteResult>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean first = true;
		
		try {
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();
			while(rs.next()) {
				String style = "";
				if(first){
					style = "display: block;";
					first = false;
				}else{
					style = "display: none;";
				}
				String suiteResultID = rs.getString("SuiteResultId");
				String testSuiteID = rs.getString("TestSuiteID");
				String suiteRunTime = rs.getString("SuiteRunTime");
				
				suiteResult.add(new SuiteResult(Integer.parseInt(suiteResultID), Integer.parseInt(testSuiteID), suiteRunTime, style));
			}
			rs.close();
		}catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}try {
			if(rs != null && !rs.isClosed())
				rs.close();
			if(ps != null && !ps.isClosed())
				ps.close();
			if(conn != null && !conn.isClosed())
				conn.close();
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		return suiteResult;	
	}
	
}
